package com.cloudtechmasters.devopsweekendsession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevopsWeekendSessionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevopsWeekendSessionApplication.class, args);
	}

}
