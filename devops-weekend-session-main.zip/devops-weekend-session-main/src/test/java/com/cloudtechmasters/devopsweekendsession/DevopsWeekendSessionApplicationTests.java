package com.cloudtechmasters.devopsweekendsession;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevopsWeekendSessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
